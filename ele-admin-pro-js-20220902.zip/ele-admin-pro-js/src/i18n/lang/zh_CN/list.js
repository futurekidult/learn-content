/* 列表页面 */
export default {
  // 基础列表
  basic: {
    table: {
      avatar: '头像',
      username: '用户账号',
      nickname: '用户名',
      organizationName: '组织机构',
      phone: '手机号',
      sexName: '性别',
      createTime: '创建时间',
      status: '状态',
      action: '操作'
    }
  }
};
