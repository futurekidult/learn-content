/* 列表页面 */
export default {
  // 基础列表
  basic: {
    table: {
      avatar: 'Avatar',
      username: 'Username',
      nickname: 'Nickname',
      organizationName: 'Organization',
      phone: 'Phone',
      sexName: 'Sex',
      createTime: 'CreateTime',
      status: 'Status',
      action: 'Action'
    }
  }
};
