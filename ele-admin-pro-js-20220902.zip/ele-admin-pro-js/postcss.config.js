module.exports = {
  plugins: {}
};
